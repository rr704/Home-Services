<?php include 'Header.php' ?>
<link rel="stylesheet" href="aboutus.css">
    
    <!-- About Us Section -->
    <section class="about-us">
        <div class="container">
            <div class="about-image">
                <img src="images/homesvg/aboutus.jpg" alt="Home Care Team">
            </div>
            <div class="about-content">
                <h2>About Us</h2>
                <p class="tagline">Your Trusted Home Care Partner</p>
                <p>
                    At Home Care, we are dedicated to providing exceptional home repair and maintenance services.
                    Our team of highly skilled professionals is committed to helping homeowners maintain and improve
                    their homes, ensuring that every project is completed with the highest level of quality and care.
                </p>
                <p>
                    Whether it’s fixing a leaky faucet, repairing an electrical issue, or remodeling an entire room,
                    we offer a wide range of services to meet the unique needs of our clients. With a focus on safety,
                    efficiency, and satisfaction, we aim to provide top-notch solutions tailored to every home.
                </p>
            </div>
        </div>
    </section>

<?php include 'Footer.php' ?>
