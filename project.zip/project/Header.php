
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Care Services</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="home.css">
    <script src="header.js"></script>
    <script src="jquery-3.7.1.min.js"></script>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="images/homeimages/1.Logo.png" alt="Home Care Service">
            </div>
            <div class="header-menu">
                <ul>
                    <li><a href="Home.php">HOME</a></li>
                    <li><a href="AboutUs.php">ABOUT US</a></li>
                    <li class="dropdown"><a href="#">SIGNUP/LOGIN</a>
                        <ul class="dropdown-content">
                            <li><a href="Admin/admin_login.php">Admin</a></li>
                            <li><a href="User/login_signup.php">User</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class='options'>
                <div class="container" onclick="myFunction(this)">
                    <div class="bar1"></div>
                    <div class="bar2"></div>
                    <div class="bar3"></div>
                </div>  
            </div>
        </div>
    </header>

    <section class="slogan">
        <h1>"Repair, Your Way!"</h1>
    </section>

</body>
</html>
