<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/sealingrepair/foundationsealing.webp" alt="Foundation Sealing">
                <div class="service-box-hover">
                    <span>Foundation sealing prevents water infiltration by filling cracks and gaps with sealants, protecting against moisture damage and structural issues.</span>
                </div>
                <h2>Foundation Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/roofsealing.jpg" alt="Roof Sealing">
                <div class="service-box-hover">
                    <span>Roof sealing protects against leaks and weather damage. It involves applying sealant to cracks, joints, and flashing to create a waterproof barrier.</span>
                </div>
                <h2>Roof Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/doordealing.jpg" alt="Door Sealing">
                <div class="service-box-hover">
                    <span>Door sealing prevents drafts and energy loss. It involves applying weatherstripping around door frames and thresholds to create an airtight seal.</span>
                </div>
                <h2>Door Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/countertopsealing.jpg" alt="Countertop Sealing">
                <div class="service-box-hover">
                    <span>Countertop sealing protects porous surfaces like granite and marble from stains and etching. Regular sealing maintains the countertop's appearance and durability.</span>
                </div>
                <h2>Countertop Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/windowsealing.webp" alt="Window Sealing">
                <div class="service-box-hover">
                    <span>Window sealing prevents drafts, energy loss, and water damage. It involves applying weatherstripping and caulking around window frames and sashes.</span>
                </div>
                <h2>Window Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/groutsealing.jpg" alt="Grout Sealing">
                <div class="service-box-hover">
                    <span>Grout sealing protects grout lines from stains, moisture, and mold. It involves applying a sealant to repel liquids and dirt, preserving grout's appearance.</span>
                </div>
                <h2>Grout Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/basementsealing.jpg" alt="Basement Sealing">
                <div class="service-box-hover">
                    <span>Basement sealing prevents water infiltration and dampness. It involves sealing cracks, joints, and windows to protect against moisture damage.</span>
                </div>
                <h2>Basement Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/sealingrepair/decksealing.jpeg" alt="Deck Sealing">
                <div class="service-box-hover">
                    <span>Deck sealing protects wood from moisture, sun damage, and decay. Regular sealing preserves the deck's appearance and extends its lifespan.</span>
                </div>
                <h2>Deck Sealing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p> "Excellent service! The technician sealed all the cracks in our basement walls, preventing future water leaks. He was very professional and explained the entire process clearly. Highly recommend their services!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p> "Fantastic service! The technician re-sealed our bathroom tiles, and it looks brand new. He was very meticulous and ensured every corner was properly sealed. Very satisfied with the work."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Good service. The technician was very skilled and did a great job sealing the grout in our shower. There was a bit of mess left behind, but overall, I'm happy with the service. Would recommend."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>