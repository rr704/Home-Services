<?php
session_start();
include 'database.php'; // Include the database connection

$error = '';

// Define admin credentials
$admin_email = 'admin@gmail.com';
$admin_password = '1234';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signup'])) {
        $email = $_POST['signup_email'];
        $password = $_POST['signup_password'];
        $confirm_password = $_POST['confirm_password'];
        $mobile = $_POST['signup_mobile'];
        $address = $_POST['signup_address'];

        // Basic server-side validation
        if (empty($email) || empty($password) || empty($confirm_password) || empty($mobile) || empty($address)) {
            $error = "All fields are required!";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format!";
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match!';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters long!';
        } elseif (!preg_match("/^[0-9]{10}$/", $mobile)) {
            $error = "Invalid mobile number! Mobile number must be 10 digits.";
        } elseif ($email === $admin_email && $password === $admin_password) {
            $error = "User email and password cannot match admin credentials!";
        } else {
            // Check if the email is already registered
            $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check_stmt->bind_param("s", $email);
            $check_stmt->execute();
            $check_stmt->store_result();

            if ($check_stmt->num_rows > 0) {
                $error = "Email is already registered! Please use a different email.";
            } else {
                // Prepare and bind
                $stmt = $conn->prepare("INSERT INTO users (email, password, mobile, address) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("ssss", $email, $password, $mobile, $address);

                if ($stmt->execute()) {
                    // Retrieve the user ID of the newly created account
                    $user_id = $stmt->insert_id;

                    // Set session variables for the user
                    $_SESSION['loggedin'] = true;
                    $_SESSION['id'] = $user_id;
                    $_SESSION['email'] = $email;

                    header('Location: Home.php');
                    exit;
                } else {
                    $error = "Error: " . $stmt->error;
                }

                $stmt->close();
            }

            $check_stmt->close();
        }
    } elseif (isset($_POST['login'])) {
        $email = $_POST['login_email'];
        $password = $_POST['login_password'];

        // Prevent user login with admin credentials
        if ($email === $admin_email && $password === $admin_password) {
            $error = "Invalid user email or password!";
        } else {
            $stmt = $conn->prepare("SELECT id, password FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $stmt->bind_result($user_id, $stored_password);
                $stmt->fetch();

                if ($password === $stored_password) {
                    // Set session variables for the user
                    $_SESSION['loggedin'] = true;
                    $_SESSION['id'] = $user_id;
                    $_SESSION['email'] = $email;

                    header('Location: Home.php');
                    exit;
                } else {
                    $error = 'Invalid email or password!';
                }
            } else {
                $error = 'Invalid email or password!';
            }

            $stmt->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Login & Registration Form</title>
  <link rel="stylesheet" href="CSS/style.css">
  <link rel="stylesheet" href="CSS/sign.css">
</head>
<body>

<div class="container">
    <input type="checkbox" id="check">
    <div class="registration form">
      <header>Signup</header>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form id="signup-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="email" id="signup-email" name="signup_email" placeholder="Enter your email" required>
            <input type="password" id="signup-password" name="signup_password" placeholder="Create a password" required>
            <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm your password" required>
            <input type="text" id="signup-mobile" name="signup_mobile" placeholder="Enter your mobile number" required> 
            <input type="text" id="signup-address" name="signup_address" placeholder="Enter your address" required>
            <input type="submit" class="button" name="signup" value="Signup"> 
        </form>
        <div class="toggle-form">
            <span>Already have an account? <label for="check">Login</label></span>
        </div>
    </div>

    <div class="login form">
        <header>Login</header>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form id="login-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="email" id="login-email" name="login_email" placeholder="Enter your email" required>
            <input type="password" id="login-password" name="login_password" placeholder="Enter your password" required>
            <a href="forgotpassword.php">Forgot password?</a>
            <input type="submit" class="button" name="login" value="Login">
        </form>
        <div class="toggle-form">
            <span>Don't have an account? <label for="check">Signup</label></span>
        </div>
    </div>
</div>

</body>
</html>
