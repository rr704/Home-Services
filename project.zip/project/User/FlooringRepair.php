<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/flooringrepair/woodfloorrepair.jpg" alt="Wood Floor Repair">
                <div class="service-box-hover">
                    <span>Wood floor repair focuses on restoring damaged wooden floorboards. Common issues include scratches, dents, squeaks, and worn finishes, requiring techniques like sanding, refinishing, and replacing damaged planks.</span>
                </div>
                <h2>Wood Floor Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/carpetrepair.jpg" alt="Carpet Repair">
                <div class="service-box-hover">
                    <span>Carpet repair focuses on fixing damages like stains, burns, tears, and loose fibers. Common methods include stain removal, patching, gluing, and professional stretching to restore carpet's appearance and functionality.</span>
                </div>
                <h2>Carpet Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/corkfloor.jpg" alt="Cork Floor Repair">
                <div class="service-box-hover">
                    <span>Cork floor repair involves fixing dents, scratches. Methods include filling dents with cork dust and polyurethane and applying protective coatings to restore the floor's appearance.</span>
                </div>
                <h2>Cork Floor Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/tilefloor.jpg" alt="Tile Floor Repair">
                <div class="service-box-hover">
                    <span>Tile floor repair involves fixing cracked, chipped, or loose tiles. It includes removing damaged tiles, preparing the surface, installing new tiles, and grouting to restore the floor's appearance and functionality.</span>
                </div>
                <h2>Tile Floor Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/subfloor.jpg" alt="SubFloor Repair">
                <div class="service-box-hover">
                    <span>Subfloor repair addresses issues beneath the visible flooring, such as rot, sagging, or squeaks. It involves replacing damaged sections, leveling the surface, and reinforcing the underlying structure for a stable base.</span>
                </div>
                <h2>SubFloor Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/floorleveling.jpg" alt="Floor Leveling">
                <div class="service-box-hover">
                    <span>Floor leveling creates a smooth and even surface for new flooring. It involves using leveling compounds, plywood, or shims to address unevenness and ensure proper installation of the finished floor.</span>
                </div>
                <h2>Floor Leveling</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/laminaterepair.jpg" alt="Laminate Repair">
                <div class="service-box-hover">
                    <span>Laminate repair focuses on fixing scratches, dents, and gaps in laminate flooring. It involves using repair kits, fillers, and replacement planks to restore the floor's appearance and functionality.</span>
                </div>
                <h2>Laminate Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/flooringrepair/concretefloor.jpg" alt="Concerete Floor Repair">
                <div class="service-box-hover">
                    <p>Concrete floor repair involves fixing cracks, chips, and spalls. It includes cleaning the damaged area, applying concrete repair mortar, leveling, and finishing for a seamless and durable surface.</p>
                </div>
                <h2>Concerete Floor Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"The service was outstanding! The technician did a fantastic job repairing the damaged floorboards. It looks as good as new. He was very professional and cleaned up thoroughly after the job. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p> "Excellent service! The technician was very skilled and replaced the cracked tiles perfectly. He matched the grout color exactly, and it looks seamless. Will definitely use this service again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Good service overall. The technician was professional and did a good job fixing the loose tiles. There was a slight delay in the scheduled time, but the quality of work made up for it. Would recommend."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>
    
<?php include 'Footer.php'; ?>