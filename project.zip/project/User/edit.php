<?php
session_start();
require_once 'database.php'; // Include your database connection file

// Check if the user is logged in, redirect to login page if not
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login_signup.php');
    exit;
}

// Initialize variables
$mobile = $address = '';
$update_success = '';
$error = '';

if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id']; // Get user ID from session

    // Fetch current user data
    $sql = "SELECT mobile, address FROM users WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($mobile, $address);
        $stmt->fetch();
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Update user data
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $new_mobile = $_POST['mobile'];
        $new_address = $_POST['address'];

        // Update the database with the new data
        $sql_update = "UPDATE users SET mobile = ?, address = ? WHERE id = ?";
        if ($stmt_update = $conn->prepare($sql_update)) {
            $stmt_update->bind_param("ssi", $new_mobile, $new_address, $user_id);

            if ($stmt_update->execute()) {
                $update_success = "Profile updated successfully!";
                $mobile = $new_mobile;
                $address = $new_address;
                header("Location: profile.php?status=success");
                    exit;
            } else {
                $error = "Error updating profile: " . $stmt_update->error;
            }
            $stmt_update->close();
        } else {
            $error = "Error preparing statement: " . $conn->error;
        }
    }
} else {
    echo "User ID not found in session.";
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - Home Care Services</title>
    <link rel="stylesheet" href="CSS/profile.css">
</head>
<body>
    <?php include 'Header.php'; ?>

    <section class="profile">
        <div class="profile-container">
            <div class="profile-header">
                <h2>Edit Profile</h2>
            </div>
            <div class="profile-details">
                <div class="profile-info">
                    <?php if (!empty($update_success)) echo "<p style='color:green;'>$update_success</p>"; ?>
                    <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
                    <div class="profile-details">
                        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <div class="form-group">
                                <label for="mobile">Mobile Number:</label>
                                <input type="text" id="mobile" name="mobile" value="<?php echo htmlspecialchars($mobile); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="address">Address:</label>
                                <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($address); ?>" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="edit-btn">Save Changes</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <?php include 'Footer.php'; ?>
</body>
</html>
