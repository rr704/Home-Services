document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('service-form');

    // Define the states and cities data
    const statesAndCities = {
        // Your states and cities data
        "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Kurnool"],
        "Arunachal Pradesh": ["Itanagar", "Tawang", "Pasighat", "Ziro", "Tezu"],
        "Assam": ["Guwahati", "Dibrugarh", "Jorhat", "Silchar", "Nagaon"],
        "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga"],
        "Chhattisgarh": ["Raipur", "Bhilai", "Bilaspur", "Korba", "Durg"],
        "Goa": ["Panaji", "Margao", "Vasco da Gama", "Ponda", "Mapusa"],
        "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar"],
        "Haryana": ["Gurgaon", "Faridabad", "Panipat", "Ambala", "Hisar"],
        "Himachal Pradesh": ["Shimla", "Dharamshala", "Mandi", "Solan", "Kullu"],
        "Jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro", "Deoghar"],
        "Karnataka": ["Bangalore", "Mysore", "Mangalore", "Hubli-Dharwad", "Belgaum"],
        "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Thrissur", "Kannur"],
        "Madhya Pradesh": ["Indore", "Bhopal", "Gwalior", "Jabalpur", "Ujjain"],
        "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik", "Thane"],
        "Manipur": ["Imphal", "Thoubal", "Bishnupur", "Ukhrul", "Churachandpur"],
        "Meghalaya": ["Shillong", "Tura", "Nongpoh", "Jowai", "Baghmara"],
        "Mizoram": ["Aizawl", "Lunglei", "Champhai", "Kolasib", "Serchhip"],
        "Nagaland": ["Kohima", "Dimapur", "Mokokchung", "Tuensang", "Wokha"],
        "Odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Sambalpur", "Berhampur"],
        "Punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda"],
        "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner"],
        "Sikkim": ["Gangtok", "Geyzing", "Mangan", "Namchi", "Singtam"],
        "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem"],
        "Telangana": ["Hyderabad", "Warangal", "Nizamabad", "Karimnagar", "Khammam"],
        "Tripura": ["Agartala", "Udaipur", "Dharmanagar", "Kailashahar", "Ambassa"],
        "Uttar Pradesh": ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Varanasi"],
        "Uttarakhand": ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rishikesh"],
        "West Bengal": ["Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri"]
    };

    // Define the service and sub-service data
    const serviceAndSub = {
        // Your service and sub-service data
        "Furniture Repair": ["Structure Repair", "Cushion Cleaning", "Refinishing", "Furniture Modification", "Joints Repair", "Leather Repair", "Furniture Cleaning", "Furniture Polishing"],
        
            "Wall Repair": ["Structure Repair", "Painting", "DryWall Repair", "Sound Proofing", "Water Proofing", "Plaster Repair", "WallPaper Repair", "Texture Repair"],
        
            "Flooring Repair": ["Wood Floor Repair", "Carpet Repair", "Cork Floor Repair", "Tile Floor Repair", "Sub Floor Repair", "Floor Leaveling", "Laminate Repair", "Concerete Floor Repair"],
        
            "Electrical Repair": ["Outdoor Electrical Repair", "Smoke Detector Repair", "Ceiling Fan Repair", "Circuit Breaker Repair", "Switch Repair", "Lighting Repair", "Emergency Elictrical Repair", "Electrical Panel Upgrade"],
            
            "Plumbing Repair": ["Leak Repair", "Pipe Repair", "Sump Pump Repair", "Plumbing Inspections", "Fixture Repair", "Sewer Line Repair", "Water Heater Repair", "Water Presure Repair"],
        
            "Sealing Repair": ["Foundation Sealing", "Roof Sealing", "Door Sealing", "CounterTop Sealing", "Windows Sealing", "Grout Sealing", "Basement Sealing", "Deck Sealing"],
        
            "Windows Repair": ["Hardware Repair", "Glass Repair", "Caulking", "Windows Alligment", "Frame Repair", "Weather Stripping", "Screen Repair", "balance System Repair"],
        
            "Appliance Installation": ["Kitchen Appliances", "Laundry Appliances", "General Appliances", "Climate Control Appliances", "OutDoor Appliances", "Solar Appliances", "Speciality Appliances", "Home Security Appliances"]
    };

    // Populate the state dropdown
    function populateStateDropdown() {
        const stateDropdown = document.getElementById("state");
        for (const state in statesAndCities) {
            const option = document.createElement("option");
            option.value = state;
            option.text = state;
            stateDropdown.add(option);
        }
    }

    // Populate the city dropdown based on the selected state
    function populateCityDropdown() {
        const stateDropdown = document.getElementById("state");
        const cityDropdown = document.getElementById("city");
        const selectedState = stateDropdown.value;
        cityDropdown.innerHTML = ""; // Clear previous options
        if (selectedState !== "") {
            for (const city of statesAndCities[selectedState]) {
                const option = document.createElement("option");
                option.value = city;
                option.text = city;
                cityDropdown.add(option);
            }
        }
    }

    // Populate the service dropdown
    function populateServiceDropdown() {
        const serviceDropdown = document.getElementById("service");
        for (const service in serviceAndSub) {
            const option = document.createElement("option");
            option.value = service;
            option.text = service;
            serviceDropdown.add(option);
        }
    }

    // Populate the sub-service dropdown based on the selected service
    function populateSubServiceDropdown() {
        const serviceDropdown = document.getElementById("service");
        const subDropdown = document.getElementById("sub");
        const selectedService = serviceDropdown.value;
        subDropdown.innerHTML = ""; // Clear previous options
        if (selectedService !== "") {
            for (const subService of serviceAndSub[selectedService]) {
                const option = document.createElement("option");
                option.value = subService;
                option.text = subService;
                subDropdown.add(option);
            }
        }
    }

    // Initialize the dropdowns
    populateStateDropdown();
    populateServiceDropdown();

    // Add event listeners to the dropdowns
    document.getElementById("state").addEventListener("change", populateCityDropdown);
    document.getElementById("service").addEventListener("change", populateSubServiceDropdown);

    // Form validation
    form.addEventListener('submit', function (event) {
        let isValid = true;

        // Validate full name
        const fullName = document.getElementById('fullname');
        if (fullName.value.trim() === '') {
            isValid = false;
            alert('Full name is required.');
            fullName.focus();
        }

        // Validate phone number
        const phone = document.getElementById('phone');
        const phoneRegex = /^[0-9]{10,15}$/; // Simple regex for phone number validation
        if (!phoneRegex.test(phone.value.trim())) {
            isValid = false;
            alert('Please enter a valid phone number.');
            phone.focus();
        }

        // Validate country
        const country = document.getElementById('country');
        if (country.value === '') {
            isValid = false;
            alert('Country/Region is required.');
            country.focus();
        }

        // Validate state
        const state = document.getElementById('state');
        if (state.value === '') {
            isValid = false;
            alert('State is required.');
            state.focus();
        }

        // Validate city
        const city = document.getElementById('city');
        if (city.value === '') {
            isValid = false;
            alert('City is required.');
            city.focus();
        }

        // Validate pincode
        const pincode = document.getElementById('pincode');
        const pincodeRegex = /^[0-9]{6}$/; // Simple regex for Indian pincode validation
        if (!pincodeRegex.test(pincode.value.trim())) {
            isValid = false;
            alert('Please enter a valid pincode.');
            pincode.focus();
        }

        // Validate address
        const address = document.getElementById('address');
        if (address.value.trim() === '') {
            isValid = false;
            alert('Address is required.');
            address.focus();
        }

        // Validate task description
        const description = document.getElementById('description');
        if (description.value.trim() === '') {
            isValid = false;
            alert('Task description is required.');
            description.focus();
        }

        // Validate privacy policy checkbox
        const privacyPolicy = document.getElementById('privacy-policy');
        if (!privacyPolicy.checked) {
            isValid = false;
            alert('You must agree to the Privacy Policy.');
            privacyPolicy.focus();
        }

        // If the form is invalid, prevent submission
        if (!isValid) {
            event.preventDefault();
        }
    });
});
