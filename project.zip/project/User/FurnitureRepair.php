<?php include 'Header.php'; ?>


<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/furnitureimages/structurerepair.jpg" alt="Structure Repair">
                <div class="service-box-hover">
                    <span>Structure repair in furniture involves reinforcing weakened joints, fixing broken legs or frames, and restoring stability. It often requires woodworking skills, clamps, and adhesives to ensure furniture's structural integrity.</span>
                </div>
                <h2>Structure Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/cushioncleaning.webp" alt="Cushion Cleaning">
                <div class="service-box-hover">
                    <span>Cushion cleaning involves removing dirt, stains, and allergens from upholstery fabric. Professional cleaning methods like steam cleaning or dry cleaning can restore cushion's appearance and hygiene.</span>
                </div>
                <h2>Cushion Cleaning</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/refinishing.jpg" alt="Refinishing">
                <div class="service-box-hover">
                    <span>Refinishing in furniture repair involves restoring or enhancing the surface appearance. It includes techniques like sanding, staining, painting, and applying protective coatings to achieve a desired finish.</span>
                </div>
                <h2>Refinishing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/modification.jpg" alt="Modification">
                <div class="service-box-hover">
                    <span>Furniture modification involves altering a piece's appearance or function. It can include changing dimensions, adding features, or converting its purpose, requiring carpentry, upholstery, or metalworking skills.</span>
                </div>
                <h2>Furniture Modification</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/jointsrepair.webp" alt="Joints Repair">
                <div class="service-box-hover">
                    <span>Joint repair involves strengthening loose or broken connections between furniture components. Methods include gluing, doweling, or using wooden splines to restore stability and prevent future damage.</span>
                </div>
                <h2>Joints Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/leatherrepair.jpg" alt="Leather Repair">
                <div class="service-box-hover">
                    <span>Leather repair involves fixing cracks, tears, or scratches on leather furniture. It includes techniques like patching, filling, and color matching to restore the leather's original appearance.</span>
                </div>
                <h2>Leather Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/furniturecleaning.jpg" alt="Furniture Cleaning">
                <div class="service-box-hover">
                    <span>Furniture cleaning involves removing dirt, dust, and stains from surfaces and upholstery. Regular cleaning maintains hygiene and prolongs furniture's lifespan.</span>
                </div>
                <h2>Furniture Cleaning</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/furnitureimages/polishing.jpg" alt="Furniture Polishing">
                <div class="service-box-hover">
                    <span>Furniture polishing restores shine and protects the surface. It involves removing old finishes, applying waxes, polishes, or lacquers, and buffing for a glossy and lustrous finish.</span>
                </div>
                <h2>Furniture Polishing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"Amazing service! The technician fixed the broken leg on our dining table, and it’s as sturdy as ever. He was very professional and took great care in his work. I highly recommend their services."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p> "Great job on the upholstery repair. The technician matched the fabric perfectly, and it looks brand new. There was a slight delay in arrival, but the quality of work was excellent. Will use again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Good service. The technician was very professional and fixed the broken bed frame efficiently. There was a bit of dust left behind, but overall, I'm happy with the service. Would recommend."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>
