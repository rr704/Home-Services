<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/plumbingrepair/leakrepair.jpg" alt="Leak Repair">
                <div class="service-box-hover">
                    <span>Leak repair involves locating the source of water leakage and sealing it to prevent water damage. Methods include pipe replacement, tightening connections, using sealants, or addressing underlying issues.</span>
                </div>
                <h2>Leak Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/piperepair.jpg" alt="Pipe Repair">
                <div class="service-box-hover">
                    <span>Pipe repair involves fixing leaks, clogs, or breaks in pipes. Methods include replacing damaged sections, tightening joints, or using specialized repair techniques.</span>
                </div>
                <h2>Pipe Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/sumppumprepair.jpg" alt="Sump Pump Repair">
                <div class="service-box-hover">
                    <span>Sump pump repair addresses issues like motor failure, switch problems, clog, or float switch malfunctions. It involves troubleshooting, cleaning, and potentially replacing components.</span>
                </div>
                <h2>Sump Pump Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/plumbinginspections.jpg" alt="Plumbing Inspections">
                <div class="service-box-hover">
                    <span>Plumbing inspection assesses the overall condition of plumbing systems, identifying potential issues like leaks, clogs, or outdated components. It helps prevent costly repairs and ensures efficient plumbing operation.</span>
                </div>
                <h2>Plumbing Inspections</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/fixturerepair.jpg" alt="Fixture Repair">
                <div class="service-box-hover">
                    <span>Fixture repair addresses issues with faucets, toilets, sinks, and showers. It involves replacing worn parts, fixing leaks, unclogging drains, and restoring proper functionality.</span>
                </div>
                <h2>Fixture Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/sewerlinerepair.jpg" alt="Sewer Line Repair">
                <div class="service-box-hover">
                    <span>Sewer line repair addresses clogs, leaks, or breaks in the main sewer pipe. Methods include trenchless pipe lining, traditional excavation, and hydro jetting to restore proper waste disposal.</span>
                </div>
                <h2>Sewer Line Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/waterheaterrepair.jpg" alt="Water Heater Repair">
                <div class="service-box-hover">
                    <span>Water heater repair addresses issues like leaks, no hot water, or insufficient heating. It involves troubleshooting components like heating elements, thermostats, and valves.</span>
                </div>
                <h2>Water Heater Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/plumbingrepair/waterpressurerepair.png" alt="Water Pressure Repair">
                <div class="service-box-hover">
                    <span>Water pressure repair addresses issues like low or high water flow. It involves checking pipes, valves, pressure regulators, and water heaters to identify and fix the problem.</span>
                </div>
                <h2>Water Pressure Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p> "Excellent service! The plumber arrived on time and quickly fixed the leaking pipe. He was very professional and even provided tips on how to prevent future leaks. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p>"Great job! The plumber was very thorough and fixed the clogged drain efficiently. There was a slight mess left behind, but overall, I'm very satisfied with the service. Would use again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Outstanding work! The plumber responded quickly to our emergency call and repaired the burst pipe efficiently. He also checked for other potential issues and provided valuable advice. Highly recommend for any plumbing needs."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>