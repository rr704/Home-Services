<?php

// Initialize a variable for the email
$email = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle POST request
    $email = $_POST['email'];

    // Process the email (e.g., check if it exists in the database, send reset link, etc.)
    // Add your PHP code here to handle the forgot password logic

    // Example: display a success message
    echo "<p>A password reset link has been sent to $email.</p>";
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Handle GET request (if needed)
    if (isset($_GET['email'])) {
        $email = $_GET['email'];
        // Additional processing can be done here if necessary
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="CSS/sign.css">
  <title>Forgot Password</title>
</head>
<body>
  <div class="container">
    <div class="login form">
      <header>Forgot Password</header>
      <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <input type="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email); ?>" required>
        <input type="submit" class="button" value="Submit">
      </form>
      <div class="toggle-form">
        <span>Remembered? <a href="login_signup.php"><label>Login</label></a></span>
      </div>
    </div>
  </div>

</body>
</html>
