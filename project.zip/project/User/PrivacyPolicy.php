<?php include 'Header.php'; ?> 

<main>
        <section class="privacy-policy">
            <h2>Privacy Policy</h2>
            <p>Effective Date: July 30, 2024</p>
            <p>Welcome to Home Care Services. Your privacy is important to us. This privacy policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our services. Please read this policy carefully to understand our views and practices regarding your personal data.</p>

            <h3>1. Payment Process</h3>
            <p>We treat your payment process data with utmost confidentiality.</p>
            <ul>
                <li>Users must pay a visiting charge first before their service can be booked.</li>
                <li>If the user cancels the service for any reason, only half of the visiting charge will be refunded, not the full amount.</li>
                <li>We only charge for the visiting fee. If any additional items or spare parts are required, the cost of those products should be paid by the user.</li>
                <li>If any issues arise during the payment process, users can call or send an email to our contact information provided below.</li>
            </ul>

            <h3>2. Information We Collect</h3>
            <p>We may collect and process the following data about you:</p>
            <ul>
                <li><strong>Personal Identification Information:</strong> Name, email address, phone number, and address.</li>
                <li><strong>Technical Data:</strong> IP address, browser type and version, time zone setting, browser plug-in types and versions, operating system and platform, and other technology on the devices you use to access this website.</li>
                <li><strong>Usage Data:</strong> Information about how you use our website, products, and services.</li>
                <li><strong>Marketing and Communications Data:</strong> Your preferences in receiving marketing from us and your communication preferences.</li>
            </ul>

            <h3>3. How We Use Your Information</h3>
            <p>We use the information we collect in the following ways:</p>
            <ul>
                <li><strong>To provide and manage our services:</strong> Including processing your requests and payments, and providing customer support.</li>
                <li><strong>To improve our website and services:</strong> We use feedback to improve our offerings and user experience.</li>
                <li><strong>To communicate with you:</strong> About updates, promotions, and other relevant information.</li>
                <li><strong>To comply with legal obligations:</strong> We may process your data to comply with legal requirements.</li>
            </ul>

            <h3>4. How We Share Your Information</h3>
            <p>We do not sell, trade, or otherwise transfer your personal data to outside parties except as described below:</p>
            <ul>
                <li><strong>Service Providers:</strong> We may share your information with third-party service providers who perform services on our behalf.</li>
                <li><strong>Legal Requirements:</strong> We may disclose your information if required by law or in response to valid requests by public authorities.</li>
                <li><strong>Business Transfers:</strong> In the event of a merger, acquisition, or sale of all or a portion of our assets, your information may be transferred.</li>
            </ul>

            <h3>5. Security of Your Information</h3>
            <p>We use administrative, technical, and physical security measures to help protect your personal information. However, no security system is impenetrable, and we cannot guarantee the security of our systems completely.
                
            <h3>6. Your Data Protection Rights</h3>
            <p>Depending on your location, you may have the following rights regarding your personal data:</p>
            <ul>
                <li><strong>Access:</strong> The right to request copies of your personal data.</li>
                <li><strong>Rectification:</strong> The right to request that we correct any information you believe is inaccurate.</li>
                <li><strong>Erasure:</strong> The right to request that we erase your personal data, under certain conditions.</li>
                <li><strong>Restrict Processing:</strong> The right to request that we restrict the processing of your personal data, under certain conditions.</li>
                <li><strong>Object to Processing:</strong> The right to object to our processing of your personal data, under certain conditions.</li>
                <li><strong>Data Portability:</strong> The right to request that we transfer the data that we have collected to another organization, or directly to you, under certain conditions.</li>
            </ul>

            <h3>7. Third-Party Links</h3>
            <p>Our website may contain links to third-party websites. We are not responsible for the privacy practices or the content of these third-party sites. We encourage you to read the privacy policies of each website you visit.</            <h3>7. Changes to This Privacy Policy</h3>
            <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</            <h3>8. Contact Us</h3>
            <p>If you have any questions or concerns about this Privacy Policy, please contact us:</p>
            <ul>
                <li>Email: homecareservices@gmail.com</li>
                <li>Phone: +91 88888 88888</li>
                <li>Address: Surat, Gujarat, India</li>
            </ul>
        </section>
    </main>

<?php include 'Footer.php'; ?>