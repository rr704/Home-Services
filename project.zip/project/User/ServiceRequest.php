<?php
    session_start();
    require_once 'database.php'; // Include your database connection file
    
    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
        // Validate and sanitize inputs
        $country = $_POST['country'];
        $fullname = $_POST['fullname'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $state = $_POST['state'];
        $city = $_POST['city'];
        $pincode = $_POST['pincode'];
        $service = $_POST['service'];
        $sub_service = $_POST['sub_service'];
        $description = $_POST['description'];
    
        // Check if the session user ID is set
        if (isset($_SESSION['id'])) {
            $user_id = $_SESSION['id'];
            
            // Prepare an insert statement
            $sql = "INSERT INTO repair_request (user_id, country, fullname, phone, address, state, city, pincode, service, sub_service,description) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
    
            // Prepare the SQL statement
            if ($stmt = $conn->prepare($sql)) {
    
                // Bind variables to the prepared statement as parameters
                $stmt->bind_param("issssssssss", $user_id, $country, $fullname, $phone, $address, $state, $city, $pincode, $service, $sub_service, $description);
    
                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Redirect to a success page or display a success message
                    header("Location: SubmitRequest.php?status=success");
                    exit;
                } else {
                    // Output error message for debugging
                    echo "Error executing statement: " . $stmt->error;
                }
    
                // Close the statement
                $stmt->close();
            } else {
                // Output error message for debugging
                echo "Error preparing statement: " . $conn->error;
            }
        } else {
            // Redirect to login page if user ID is not set in session
            header("Location: Login.php");
            exit;
        }
    
        // Close the connection
        $conn->close();
    }


?>

<?php include 'Header.php'; ?>  
    
<main>
    <section class="service-request">
        <h2>Request For Service</h2>
        <form id="service-form" method="POST">
            <div class="form-group">
                <label for="country">Country/Region:</label>
                <select id="country" name="country" required>
                    <option value="" disabled selected>Select your country</option>
                    <option value="India">India</option>
                </select>
            </div>
            <div class="form-group">
                <label for="fullname">Full name (First and Last name):</label>
                <input type="text" id="fullname" name="fullname" placeholder="Enter Your Full Name" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone number:</label>
                <input type="tel" id="phone" name="phone" placeholder="+91 xxxxx xxxxx" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" placeholder="Apt, suite, unit, building, floor, etc.">
            </div>
            <div class="form-group inline-group">
                <div>
                    <label for="state">State:</label>
                    <select id="state" name="state" required>
                        <option value="" disabled selected>Select Your State</option>
                    </select>
                    <!-- <input type="text" name="state" class="state" id="state"> -->
                </div>
                <div>
                    <label for="city">City:</label>
                    <select id="city" name="city" required>
                        <option value="" disabled selected>Select Your City</option>
                    </select>
                    <!-- <input type="text" name="city" class="city" id="city"> -->
                </div>
                <div>
                    <label for="pincode">ZIP Code:</label>
                    <input type="text" id="pincode" name="pincode" placeholder="Enter your pincode" required>
                </div>
            </div>
              <div class="form-group inline-group">
                <div>
                    <label for="service">Service:</label>
                    <select id="service" name="service" required>
                        <option value="" disabled selected>Select Service</option>
                    </select>
                </div>
               <div>
                    <label for="sub">Sub Service:</label>
                    <select id="sub" name="sub_service" required>
                        <option value="" disabled selected>Select Sub Service</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="description">Task Description:</label>
                <textarea id="description" name="description" placeholder="Describe the task" required></textarea>
            </div>
            <div class="form-group privacy-policy-group">
                <input type="checkbox" id="privacy-policy" name="privacy-policy" required>
                <label for="privacy-policy">I agree to the <a href="PrivacyPolicy.php" id="open-privacy-policy">Privacy Policy</a></label>
            </div>    
            <div class="form-group">
                <div class="payable-amount">Visiting Charge is: <span>200 INR</span></div>
            </div>
            <div class="form-group button-group">
                <button type="submit" class="payment-button" name="submit_form">Click To Submit Request</button>
            </div>
        </form>
    </section>
</main>

<script src="JavaScript/ServiceReqValidation.js"></script>
<?php include 'Footer.php'; ?>