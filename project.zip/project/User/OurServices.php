<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login_signup.php'); // Redirect to login page if not logged in
    exit;
}

include 'header.php';
?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/homeimages/1.furniture.jpg" alt="Furniture Repair">
                <div class="service-box-hover">
                    <span>Furniture repair is the art and craft of bringing damaged or worn-out furniture back to its original glory or even enhancing its aesthetic appeal.</span>
                </div>
                <h2>Furniture Repair</h2>
                <a href="FurnitureRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.wallrepair.jpg" alt="Wall Repair">
                <div class="service-box-hover">
                    <span>Wall repair can be a straightforward task with the right tools and materials. Let's delve into common wall issues and their solutions.
                    </span>
                </div>
                <h2>Wall Repair</h2>
                <a href="WallRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.flooring.png" alt="Flooring Repair">
                <div class="service-box-hover">
                    <span>Flooring repair involves fixing damages like scratches, dents, cracks, or stains on various floor types. Common methods include filling, replacing damaged parts, and refinishing for a restored look.</span>
                </div>
                <h2>Flooring Repair</h2>
                <a href="FlooringRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.electrical.jpg" alt="Electrical Repair">
                <div class="service-box-hover">
                    <span>Electrical repair involves troubleshooting and fixing electrical systems, appliances, or wiring. It requires expertise, safety precautions, and often specialized tools to ensure proper functioning and prevent hazards.</span>
                </div>
                <h2>Electrical Repair</h2>
                <a href="ElectricalRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.plumbing.jpg" alt="Plumbing Help">
                <div class="service-box-hover">
                    <span>Plumbing repair focuses on fixing leaks, clogs, and other issues with pipes, fixtures, and drains. It requires knowledge of plumbing systems and often involves tools like wrenches and pipe cutters.  </span>
                </div>
                <h2>Plumbing Repair</h2>
                <a href="PlumbingRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.sealing.jpg" alt="Sealing Repair">
                <div class="service-box-hover">
                    <span>Sealing repair involves filling gaps, cracks, or holes with appropriate sealants to prevent leaks, drafts, or water damage. Common sealants include caulk, silicone, and polyurethane.</span>
                </div>
                <h2>Sealing Repair</h2>
                <a href="SealingRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.windowrepair.jpg" alt="Windows Repair">
                <div class="service-box-hover">
                    <span>Window repair involves fixing broken glass, damaged frames, or faulty mechanisms. Common repairs include replacing glass panes, adjusting hardware, and sealing leaks for improved insulation and security.</span>
                </div>
                <h2>Windows Repair</h2>
                <a href="WindowsRepair.php"><button class="service-button">For More...</button></a>
            </div>
            <div class="service-box">
                <img src="images/homeimages/1.appliance.jpeg" alt="Appliance Installation">
                <div class="service-box-hover">
                    <span>Appliance installation involves setting up new appliances in your home, connecting them to power and water sources. Professional installation ensures correct setup and often includes testing for optimal performance.</span>
                </div>
                <h2>Appliance Installation</h2>
                <a href="ApplianceInstallation.php"><button class="service-button">For More...</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"Great service! The team was prompt and very professional. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p>"Excellent work. They fixed my plumbing issue quickly and efficiently."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Affordable and reliable. I will definitely use their services again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

<?php include 'Footer.php'; ?>