<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/wallrepair/structurerepair.jpg" alt="Structure Repair">
                <div class="service-box-hover">
                    <span>Structure repair involves addressing damage to the wall's framework, like cracks in drywall or plaster. It requires reinforcing the underlying structure using techniques like patching, or installing additional supports.</span>
                </div>
                <h2>Structure Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/painting.jpg" alt="Painting">
                <div class="service-box-hover">
                    <span>Painting is the final step to restore its appearance. It involves preparing the surface, applying primer, and using high-quality paint to achieve a smooth, even finish that covers imperfections.</span>
                </div>
                <h2>Painting</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/drywallrepair.jpg" alt="Drywall Repair">
                <div class="service-box-hover">
                    <span>Drywall repair involves fixing holes, cracks, or dents in drywall surfaces. It includes patching damaged areas with drywall compound, sanding for smoothness, and applying finishing coats for a seamless blend.</span>
                </div>
                <h2>Drywall Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/soundproofing.jpg" alt="Sound Proofing">
                <div class="service-box-hover">
                    <span>Soundproofing involves adding materials to reduce noise transmission through walls. This includes using insulation, sound-absorbing panels, and resilient channels to create a barrier against unwanted sound.</span>
                </div>
                <h2>Sound Proofing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/waterproofing.jpg" alt="Water Proofing">
                <div class="service-box-hover">
                    <span>Waterproofing involves protecting walls from moisture damage. It includes applying water-resistant coatings, sealants, or membranes to prevent water penetration, mold growth, and structural damage.</span>
                </div>
                <h2>Water Proofing</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/plasterrepair.jpg" alt="Plaster Repair">
                <div class="service-box-hover">
                    <span>Plaster repair involves fixing cracks, holes, or damaged areas in plaster walls. It includes removing loose plaster, applying patching compound, and finishing with skim coats for a smooth surface.</span>
                </div>
                <h2>Plaster Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/wallpaperrepair.avif" alt="Wallpaper Repair">
                <div class="service-box-hover">
                    <span>Wallpaper repair involves fixing damaged areas like tears, bubbles, or loose seams. It requires using wallpaper paste or adhesive, a smoothing tool, and often matching wallpaper for seamless repair.</span>
                </div>
                <h2>Wallpaper Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/wallrepair/texture.jpg" alt="Texture Repair">
                <div class="service-box-hover">
                    <span>Texture repair involves restoring the original wall texture after repairs. Techniques include applying matching texture, using stencils or rollers, and blending the repaired area seamlessly with the surrounding wall.</span>
                </div>
                <h2>Texture Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"Great job! The technician arrived on time and did a thorough job fixing the cracks in our bedroom walls. There was a bit of dust left behind, but overall, I'm very satisfied with the service. Will definitely use again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p> "Fantastic service! The technician patched all the small holes and repainted the hallway walls. He was very meticulous and made sure the paint matched perfectly. The walls look flawless now. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p> "Outstanding service! The technician did an amazing job repairing the large hole in our living room wall. He was very professional and matched the paint perfectly. You can't even tell there was ever any damage. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>