<?php include 'Header.php'; ?>

    <main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/applianceinstallation/kitchen.jpg" alt="Kitchen Appliances">
                <div class="service-box-hover">
                    <span>Kitchen appliances include refrigerators, ovens, stoves, dishwashers, and microwaves. Their installation requires proper electrical and plumbing connections, along with leveling and securing for safe operation.</span>
                </div>
                <h2>Kitchen Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/laundry.jpg" alt="Laundry Appliances">
                <div class="service-box-hover">
                    <span>Laundry appliances include washing machines and dryers. Their installation requires proper electrical connections, venting, and leveling for efficient and safe operation.</span>
                </div>
                <h2>Laundry Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/general.jpg" alt="General Appliances">
                <div class="service-box-hover">
                    <span>General appliances include a wide range of household equipment. Their installation requires proper electrical and plumbing connections, along with appropriate venting and securing for safe and efficient operation.</span>
                </div>
                <h2>General Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/climatecontrol.jpg" alt="Climate Control Appliances">
                <div class="service-box-hover">
                    <span>Climate control appliances include air conditioners, heaters, and dehumidifiers. Their installation requires proper electrical connections, venting, and drainage for efficient and comfortable indoor environments.</span>
                </div>
                <h2>Climate Control Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/outdoor.webp" alt="Outdoor Appliances">
                <div class="service-box-hover">
                    <span>Outdoor appliances like grills, refrigerators, and heaters require specialized installation. They need weatherproof connections, proper venting, and often require dedicated electrical or gas lines.</span>
                </div>
                <h2>Outdoor Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/solar.jpg" alt="Solar Appliances">
                <div class="service-box-hover">
                    <span>Solar appliances like water heaters and lights require specialized installation. They involve connecting to solar panels, inverters, and batteries for harnessing solar energy.</span>
                </div>
                <h2>Solar Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/specialityAppliances.jpeg" alt="Speciality Appliances">
                <div class="service-box-hover">
                    <span>Speciality appliances like wine coolers, coffee machines, and ice makers require specific installation needs. They often involve specialized electrical connections, plumbing, and ventilation for optimal performance.</span>
                </div>
                <h2>Speciality Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/applianceinstallation/homesecurity.jpg" alt="Home Security Appliances">
                <div class="service-box-hover">
                    <span>Home security appliances like alarms, cameras, and sensors require professional installation. Proper placement, wiring, and integration with control panels ensure optimal security and protection.</span>
                </div>
                <h2>Home Security Appliances</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"The service was great, and the technician was on time. There was a minor issue with the alignment, but it was fixed immediately. Overall, very satisfied with the service."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p>"Excellent service! The technician was friendly and knowledgeable. He also helped me move the old fridge to the garage. I will definitely use this service again."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"The installation was flawless. The technician arrived on time and did an outstanding job. Very happy with the service."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>


    <?php include 'Footer.php'; ?>
    