<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/windowrepair/hardwarerepair.jpeg" alt="Hardware Repair">
                <div class="service-box-hover">
                    <span>Hardware repair addresses issues with window components like handles, locks, hinges, and balances. It involves replacing broken parts, adjusting mechanisms, and ensuring smooth window operation.</span>
                </div>
                <h2>Hardware Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/glassrepair.jpg" alt="Glass Repair">
                <div class="service-box-hover">
                    <span>Glass repair involves replacing broken or cracked window panes with new ones. Proper measurements and installation are crucial for energy efficiency and safety.</span>
                </div>
                <h2>Glass Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/caulkingrepair.jpg" alt="Caulking">
                <div class="service-box-hover">
                    <span>Caulking seals gaps around window frames, preventing air leaks and water infiltration. It improves energy efficiency and reduces drafts.</span>
                </div>
                <h2>Caulking</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/windowallignment.jpeg" alt="Window Allignment">
                <div class="service-box-hover">
                    <span>Window alignment ensures proper closing, sealing, and energy efficiency. It involves adjusting sashes, frames, and hardware to achieve a snug fit.</span>
                </div>
                <h2>Window Allignment</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/framerepair.png" alt="Frame Repair">
                <div class="service-box-hover">
                    <span>Frame repair addresses damage to window frames, including rot, cracks, and warping. It involves replacing damaged sections, reinforcing weak spots, and restoring the frame's structural integrity.</span>
                </div>
                <h2>Frame Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/weatherstripping.jpg" alt="Weather Stripping">
                <div class="service-box-hover">
                    <span>Weather stripping seals gaps around window frames, preventing air leaks and energy loss. It improves insulation, reduces drafts, and enhances comfort.</span>
                </div>
                <h2>Weather Stripping</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/screenrepair.jpg" alt="Screen Repair">
                <div class="service-box-hover">
                    <span>Screen repair involves fixing damaged or torn screen mesh. It includes replacing damaged sections, tightening loose frames, and reattaching the screen for proper insect protection.</span>
                </div>
                <h2>Screen Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/windowrepair/balancesyste.jpg" alt="Balance System Repair">
                <div class="service-box-hover">
                    <span>Balance system repair restores smooth window operation. It involves adjusting or replacing broken balance weights and springs to ensure proper window opening and closing.</span>
                </div>
                <h2>Balance System Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"Fantastic service! The technician arrived on time and replaced the broken window pane quickly and efficiently. He was very professional and left the area clean. Highly recommend their services!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p>"Excellent service! The technician sealed all the drafts around our bedroom windows, and the difference is amazing. He was very thorough and explained the entire process. Very pleased with the results."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p> "Outstanding work! The technician replaced the cracked glass in our kitchen window seamlessly. He was very professional and ensured everything was cleaned up after the job. Highly recommend!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>