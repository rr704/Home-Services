<?php
session_start();
require_once 'database.php'; // Include your database connection file

// Check if the user is logged in, redirect to login page if not
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login_signup.php');
    exit;
}

if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id']; // Get user ID from session

    // Query to check if the user still exists
    $sql_check_user = "SELECT id FROM users WHERE id = ?";
    if ($stmt_check_user = $conn->prepare($sql_check_user)) {
        $stmt_check_user->bind_param("i", $user_id);
        $stmt_check_user->execute();
        $stmt_check_user->store_result();

        // If no user is found, destroy session and redirect to login
        if ($stmt_check_user->num_rows == 0) {
            session_destroy();
            header('Location: login_signup.php');
            exit;
        }

        $stmt_check_user->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    echo "User ID not found in session.";
}

// Handle the logout action
if (isset($_POST['logout'])) {
    session_destroy(); // Destroy the session to log the user out
    header('Location: Home.php');
    exit;
}

// Handle the cancel request action (delete the request from the database)
if (isset($_POST['cancel_request_id'])) {
    $cancel_request_id = $_POST['cancel_request_id'];
    
    $sql_delete = "DELETE FROM repair_request WHERE id = ?";
    if ($stmt_delete = $conn->prepare($sql_delete)) {
        $stmt_delete->bind_param("i", $cancel_request_id);
        $stmt_delete->execute();
        $stmt_delete->close();
    } else {
        echo "Error preparing delete statement: " . $conn->error;
    }
}

// Initialize variables with default values
$email = $password = $mobile = $address = '';
$requests = []; // Initialize as an empty array

// Fetch user details from the database
if (isset($_SESSION['id'])) {
    $user_id = $_SESSION['id']; // Get user ID from session

    $sql = "SELECT email, password, mobile, address FROM users WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($email, $password, $mobile, $address); 
        $stmt->fetch();
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

    // Fetch user requests for repair
    $sql_requests = "SELECT id, country, fullname, phone, address, state, city, pincode, service, sub_service, description , created_at
                     FROM repair_request 
                     WHERE user_id = ?";
    if ($stmt_requests = $conn->prepare($sql_requests)) {
        $stmt_requests->bind_param("i", $user_id);
        $stmt_requests->execute();
        $result = $stmt_requests->get_result();
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $requests[] = $row;
            }
        }
        $stmt_requests->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }

} else {
    echo "User ID not found in session.";
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile - Home Care Services</title>
    <link rel="stylesheet" href="CSS/profile.css">
</head>
<body>
    <?php include 'Header.php'; ?>

    <section class="profile">
        <div class="profile-container">
            <div class="profile-header">
                <h2>User Profile</h2>
            </div>
            <div class="profile-details">
                <div class="profile-info">
                    <p>Email: <?php echo htmlspecialchars($email); ?></p>
                    <p>Password:<?php echo str_repeat('•', 8); ?></span></p>
                    <p>Mobile: <?php echo htmlspecialchars($mobile); ?></p>
                    <p>Address: <?php echo htmlspecialchars($address); ?></p>
                        <button class="edit-btn" onclick="window.location.href='edit.php';">Edit  Profile</button>
                        <form method="POST">
                            <button type="submit" name="logout" class="logout-btn">Logout</button>
                        </form>
                </div>
            </div>

            <div class="user-requests">
                <h3>Your Repair Requests</h3>
                <?php if (count($requests) > 0): ?>
                    <ul>
                        <?php foreach ($requests as $request): ?>
                            <li>
                                <p>Country: <?php echo htmlspecialchars($request['country']); ?></p>
                                <p>Full Name: <?php echo htmlspecialchars($request['fullname']); ?></p>
                                <p>Phone: <?php echo htmlspecialchars($request['phone']); ?></p>
                                <p>Address: <?php echo htmlspecialchars($request['address']); ?></p>
                                <p>State: <?php echo htmlspecialchars($request['state']); ?></p>
                                <p>City: <?php echo htmlspecialchars($request['city']); ?></p>
                                <p>Pincode: <?php echo htmlspecialchars($request['pincode']); ?></p>
                                <p>Service: <?php echo htmlspecialchars($request['service']); ?></p>
                                <p>Sub Service: <?php echo htmlspecialchars($request['sub_service']); ?></p>
                                <p>Description: <?php echo htmlspecialchars($request['description']); ?></p>
                                <p>Request Date: <?php echo htmlspecialchars($request['created_at']); ?></p>
                                
                
                                <a href="editrequest.php?id=<?php echo $request['id']; ?>" class="edit-request-btn">Edit Request</a>
                                
                                
                                <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this request?');">
                                    <input type="hidden" name="cancel_request_id" value="<?php echo $request['id']; ?>">
                                    <button type="submit" class="cancel-request-btn">Cancel Request</button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>You have no repair requests.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php include 'Footer.php'; ?>
</body>
</html>
