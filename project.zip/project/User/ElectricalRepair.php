<?php include 'Header.php'; ?>

<main>
        <section id="service-boxes">
            <div class="service-box">
                <img src="images/electricalrepair/outdoorelectrical.jpg" alt="Outdoor Electrical Repair">
                <div class="service-box-hover">
                    <span>Outdoor electrical repair addresses issues with wiring, outlets, and fixtures exposed to weather. It requires specialized knowledge and precautions due to potential hazards.</span>
                </div>
                <h2>Outdoor Electrical Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/smokedetector.webp" alt="Smoke Detector Repair">
                <div class="service-box-hover">
                    <span>Smoke detector repair involves troubleshooting malfunctioning units. Common issues include battery replacement, sensor cleaning, wiring checks, and potential unit replacement.</span>
                </div>
                <h2>Smoke Detector Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/celingfanrepair.jpg" alt="Ceiling Fan Repair">
                <div class="service-box-hover">
                    <span>Ceiling fan repair involves troubleshooting issues like motor problems, faulty switches, unbalanced blades, or noisy operation. It often requires electrical knowledge and proper safety precautions.</span>
                </div>
                <h2>Ceiling Fan Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/circuitbreakeer.jpg" alt="Circuit Breaker Repair">
                <div class="service-box-hover">
                    <span>Circuit breaker repair involves troubleshooting and fixing faulty breakers. Common issues include tripping, overheating, and internal damage, requiring replacement or resetting.</span>
                </div>
                <h2>Circuit Breaker Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/switchrepair.jpg" alt="Switch Repair">
                <div class="service-box-hover">
                    <span>Switch repair involves troubleshooting issues like malfunctioning, flickering, or non-functioning switches. It requires identifying the problem, safely disconnecting power, and replacing or repairing the switch.</span>
                </div>
                <h2>Switch Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/lightingrepair.webp" alt="Lighting Repair">
                <div class="service-box-hover">
                    <span>Lighting repair involves troubleshooting and fixing issues with lamps, fixtures, and wiring. Common problems include burnt-out bulbs, faulty switches, and electrical shorts.</span>
                </div>
                <h2>Lighting Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/emergencyelectricsal.jpg" alt="Emergency Electrical Repair">
                <div class="service-box-hover">
                    <span>Emergency electrical repair addresses urgent electrical issues like power outages, electrical fires, or shocks. It requires immediate attention from qualified professionals for safety and to prevent further damage.</span>
                </div>
                <h2>Emergency Electrical Repair</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
            <div class="service-box">
                <img src="images/electricalrepair/electricalpanel.jpg" alt="Electrical Panel Upgrade">
                <div class="service-box-hover">
                    <span>Electrical panel upgrade replaces an outdated panel with a modern one, increasing capacity, safety, and efficiency. It often involves upgrading the service entrance and rewiring for improved electrical performance.</span>
                </div>
                <h2>Electrical Panel Upgrade</h2>
                <a href="ServiceRequest.php"><button class="service-button">For Service</button></a>
            </div>
        </section>
        <section id="reviews">
            <h2>Customer Reviews</h2>
            <div class="review">
                <p>"Fantastic service! The electrician was very knowledgeable and quickly identified and fixed the issue. He also gave us tips on how to prevent future problems. Highly recommended!"</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Jane Doe</p>
            </div>
            <div class="review">
                <p> "The electrician was punctual and efficient. He fixed the switch in no time. The only reason I didn't give 5 stars is because he arrived 15 minutes late, but he did call to inform us ahead of time.""Excellent work. They fixed my plumbing issue quickly and efficiently."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- John Smith</p>
            </div>
            <div class="review">
                <p>"Amazing service! The electrician was very professional and installed the outlets perfectly. He even cleaned up after the job was done. I’m very satisfied with the work."</p>
                <p>⭐⭐⭐⭐⭐</p>
                <p class="reviewer">- Emily Johnson</p>
            </div>
        </section>
    </main>

    <?php include 'Footer.php'; ?>