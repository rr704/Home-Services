<link rel="stylesheet" href="CSS/RequestSubmit.css">

<div class="container">
        <div class="content">
            <img src="images/successfull.png" alt="Confirmation" class="confirmation-image">
            <h1>Thank You!</h1>
            <p>Your service request has been submitted successfully.</p>
            <a href="profile.php" class="home-button">Return to Profile</a>
        </div>
    </div>

 