<?php
    session_start();
    require_once 'database.php'; // Include your database connection file

    // Check if the user is logged in and if the request ID is provided
    if (!isset($_SESSION['id'])) {
        header("Location: Login.php");
        exit;
    }
    
    $user_id = $_SESSION['id'];
    $request_id = $_GET['id']; // Get the request ID from URL

    // Fetch the existing request details from the database
    $sql = "SELECT * FROM repair_request WHERE id = ? AND user_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ii", $request_id, $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $request = $result->fetch_assoc();

        // Check if the request exists
        if (!$request) {
            echo "Invalid request ID.";
            exit;
        }
        
        $stmt->close();
    } else {
        echo "Error fetching request: " . $conn->error;
        exit;
    }

    // Process the form if it's submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form inputs
        $country = $_POST['country'];
        $fullname = $_POST['fullname'];
        $phone = $_POST['phone'];
        $address = $_POST['address'];
        $state = $_POST['state'];
        $city = $_POST['city'];
        $pincode = $_POST['pincode'];
        $service = $_POST['service'];
        $sub_service = $_POST['sub_service'];
        $description = $_POST['description'];

        // Prepare an update statement
        $sql = "UPDATE repair_request SET country = ?, fullname = ?, phone = ?, address = ?, state = ?, city = ?, pincode = ?, service = ?, sub_service = ?, description = ? WHERE id = ? AND user_id = ?";
        
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("ssssssssssii", $country, $fullname, $phone, $address, $state, $city, $pincode, $service, $sub_service, $description, $request_id, $user_id);
            
            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to a success page
                header("Location: profile.php?id=$request_id&status=success");
                exit;
            } else {
                echo "Error updating request: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error preparing update statement: " . $conn->error;
        }
    }

    // Close the connection
    $conn->close();
?>

<?php include 'Header.php'; ?>

<main>
    <section class="service-request">
        <h2>Edit Your Service Request</h2>
        <form id="service-form" method="POST">
            <!-- Country -->
            <div class="form-group">
                <label for="country">Country/Region:</label>
                <select id="country" name="country" required>
                    <option value="India" <?= ($request['country'] == 'India') ? 'selected' : ''; ?>>India</option>
                </select>
            </div>
            <!-- Full Name -->
            <div class="form-group">
                <label for="fullname">Full name (First and Last name):</label>
                <input type="text" id="fullname" name="fullname" value="<?= $request['fullname']; ?>" required>
            </div>
            <!-- Phone Number -->
            <div class="form-group">
                <label for="phone">Phone number:</label>
                <input type="tel" id="phone" name="phone" value="<?= $request['phone']; ?>" required>
            </div>
            <!-- Address -->
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" name="address" value="<?= $request['address']; ?>" required>
            </div>
            <!-- State, City, Pincode -->
            <div class="form-group inline-group">
                <div>
                    <label for="state">State:</label>
                    <select id="state" name="state" required>
                        <option value="<?= $request['state']; ?>"><?= $request['state']; ?></option>
                    </select>
                </div>
                <div>
                    <label for="city">City:</label>
                    <select id="city" name="city" required>
                        <option value="<?= $request['city']; ?>"><?= $request['city']; ?></option>
                    </select>
                </div>
                <div>
                    <label for="pincode">ZIP Code:</label>
                    <input type="text" id="pincode" name="pincode" value="<?= $request['pincode']; ?>" required>
                </div>
            </div>
            <!-- Service and Sub Service -->
            <div class="form-group inline-group">
                <div>
                    <label for="service">Service:</label>
                    <select id="service" name="service" required>
                        <option value="<?= $request['service']; ?>"><?= $request['service']; ?></option>
                    </select>
                </div>
                <div>
                    <label for="sub_service">Sub Service:</label>
                    <select id="sub" name="sub_service" required>
                        <option value="<?= $request['sub_service']; ?>"><?= $request['sub_service']; ?></option>
                    </select>
                </div>
            </div>
            <!-- Description -->
            <div class="form-group">
                <label for="description">Task Description:</label>
                <textarea id="description" name="description" required><?= $request['description']; ?></textarea>
            </div>
            <!-- Privacy Policy -->
            <div class="form-group privacy-policy-group">
                <input type="checkbox" id="privacy-policy" name="privacy-policy" required>
                <label for="privacy-policy">I agree to the <a href="PrivacyPolicy.php" id="open-privacy-policy">Privacy Policy</a></label>
            </div>
            <!-- Submit Button -->
            <div class="form-group button-group">
                <button type="submit" class="payment-button">Update Request</button>
            </div>
        </form>
    </section>
</main>

<script src="JavaScript/ServiceReqValidation.js"></script>
<?php include 'Footer.php'; ?>
