<?php
session_start();
require_once 'database.php'; // Include your database connection file

// Check if the admin is logged in, redirect to login page if not
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role'] !== 'admin') {
    // Redirect to admin login if session not set or user is not admin
    header('Location: admin_login.php');
    exit;
}

// Handle delete user action
if (isset($_POST['delete_user_id'])) {
    $delete_user_id = $_POST['delete_user_id'];

    // First delete the user's repair requests
    $sql_delete_requests = "DELETE FROM repair_request WHERE user_id = ?";
    if ($stmt_delete_requests = $conn->prepare($sql_delete_requests)) {
        $stmt_delete_requests->bind_param("i", $delete_user_id);
        $stmt_delete_requests->execute();
        $stmt_delete_requests->close();
    }

    // Then delete the user
    $sql_delete_user = "DELETE FROM users WHERE id = ?";
    if ($stmt_delete_user = $conn->prepare($sql_delete_user)) {
        $stmt_delete_user->bind_param("i", $delete_user_id);
        $stmt_delete_user->execute();
        $stmt_delete_user->close();
    }
}

// Handle cancel request action
if (isset($_POST['cancel_request_id'])) {
    $cancel_request_id = $_POST['cancel_request_id'];
    
    $sql_delete_request = "DELETE FROM repair_request WHERE id = ?";
    if ($stmt_delete_request = $conn->prepare($sql_delete_request)) {
        $stmt_delete_request->bind_param("i", $cancel_request_id);
        $stmt_delete_request->execute();
        $stmt_delete_request->close();
    }
}

// Fetch all users and their requests
$users = [];
$sql_users = "SELECT id, email, mobile, address, created_at FROM users";
if ($result_users = $conn->query($sql_users)) {
    while ($user = $result_users->fetch_assoc()) {
        $user_id = $user['id'];

        // Fetch repair requests for each user
        $sql_requests = "SELECT id,country, fullname, phone, address, state, city, pincode, service, sub_service, description, created_at FROM repair_request WHERE user_id = ?";
        if ($stmt_requests = $conn->prepare($sql_requests)) {
            $stmt_requests->bind_param("i", $user_id);
            $stmt_requests->execute();
            $result_requests = $stmt_requests->get_result();

            // Add requests to the user data
            $user['requests'] = $result_requests->fetch_all(MYSQLI_ASSOC);
            $users[] = $user;

            $stmt_requests->close();
        }
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Requests</title>
    <link rel="stylesheet" href="CSS/admin.css">
</head>
<body>
    <?php include 'Header.php'; ?>

    <section class="admin-section">
        <div class="admin-container">
            <h2>User Requests</h2>
            <?php if (count($users) > 0): ?>
                <?php foreach ($users as $user): ?>
                    <!-- User Card Box -->
                    <div class="user-box">
                        <h3>User Info</h3>

                        <!-- User Info Table -->
                        <table class="user-info-table">
                            <tr>
                                <th>Email</th>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                            </tr>
                            <tr>
                                <th>Mobile</th>
                                <td><?php echo htmlspecialchars($user['mobile']); ?></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td><?php echo htmlspecialchars($user['address']); ?></td>
                            </tr>
                            <tr>
                                <th>Created At</th>
                                <td><?php echo htmlspecialchars($user['created_at']); ?></td>
                            </tr>
                        </table>

                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this user? This will also delete all their repair requests.');">
                            <input type="hidden" name="delete_user_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" class="delete-user-btn">Delete User</button>
                        </form>

                        <h4>User Repair Requests</h4>
                        <?php if (count($user['requests']) > 0): ?>
                            <table class="request-table">
                                <thead>
                                    <tr>
                                        <th>Country</th>
                                        <th>Full Name</th>
                                        <th>Phone</th>
                                        <th>Address</th>
                                        <th>State</th>
                                        <th>City</th>
                                        <th>Pincode</th>
                                        <th>Service</th>
                                        <th>Sub Service</th>
                                        <th>Description</th>
                                        <th>Request Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($user['requests'] as $request): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($request['country']); ?></td>
                                            <td><?php echo htmlspecialchars($request['fullname']); ?></td>
                                            <td><?php echo htmlspecialchars($request['phone']); ?></td>
                                            <td><?php echo htmlspecialchars($request['address']); ?></td>
                                            <td><?php echo htmlspecialchars($request['state']); ?></td>
                                            <td><?php echo htmlspecialchars($request['city']); ?></td>
                                            <td><?php echo htmlspecialchars($request['pincode']); ?></td>
                                            <td><?php echo htmlspecialchars($request['service']); ?></td>
                                            <td><?php echo htmlspecialchars($request['sub_service']); ?></td>
                                            <td><?php echo htmlspecialchars($request['description']); ?></td>
                                            <td><?php echo htmlspecialchars($request['created_at']); ?></td>
                                            <td>
                                                <form method="POST" onsubmit="return confirm('Are you sure you want to cancel this request?');">
                                                    <input type="hidden" name="cancel_request_id" value="<?php echo $request['id']; ?>">
                                                    <button type="submit" class="cancel-request-btn">Cancel Request</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <p>No repair requests for this user.</p>
                        <?php endif; ?>
                    </div> 
                <?php endforeach; ?>
            <?php else: ?>
                <p>No users found.</p>
            <?php endif; ?>
        </div>
    </section>

    <?php include 'Footer.php'; ?>
</body>
</html>
