<?php
session_start();

$error = '';

// Define admin credentials
$admin_email = 'admin@gmail.com';
$admin_password = '1234';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['login'])) {
        $email = $_POST['login_email'];
        $password = $_POST['login_password'];

        // Check if the credentials are for admin
        if ($email === $admin_email && $password === $admin_password) {
            // Set session variables for admin
            $_SESSION['loggedin'] = true;
            $_SESSION['email'] = $admin_email;
            $_SESSION['role'] = 'admin'; // You can use this to differentiate admin

            header('Location: Home.php');
            exit;
        } else {
            $error = 'Invalid email or password!';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin Login</title>
  <link rel="stylesheet" href="CSS/style.css">
  <link rel="stylesheet" href="CSS/sign.css">
  <script src="JavaScript/Validation.js"></script>
</head>
<body>

<div class="container">
    <div class="login form">
        <header>Admin Login</header>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form id="login-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <input type="email" id="login-email" name="login_email" placeholder="Enter your email" required>
            <input type="password" id="login-password" name="login_password" placeholder="Enter your password" required>
            <a href="forgotpassword.php">Forgot password?</a>
            <input type="submit" class="button" name="login" value="Login">
        </form>
    </div>
</div>



</body>
</html>
