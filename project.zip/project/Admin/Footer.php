
<footer>
    <div class="footer-content">
        <div class="footer-info">
            <div class="footer-item">
                <a href="https://maps.app.goo.gl/DdXeJyDVVYxgCAMKA" target="_blank"><img src="images/footer/location.png" alt="Address Icon"></a>
                <p>Surat, Gujarat, India.</p>
            </div>
            <div class="footer-item">
                <img src="images/footer/mail.png" alt="Email Icon">
                <p>homecareservices@gmail.com</p>
            </div>
            <div class="footer-item">
                <img src="images/footer/phone.png" alt="Phone Icon">
                <p>+91 88888 88888</p>
            </div>
        </div>
        <div class="footer-social">
            <a href="https://www.facebook.com" target="_blank"><img src="images/footer/facebook.png" alt="Facebook"></a>
            <a href="https://www.twitter.com" target="_blank"><img src="images/footer/twitter.png" alt="Twitter"></a>
            <a href="https://www.linkedin.com" target="_blank"><img src="images/footer/linkedin.webp" alt="LinkedIn"></a>
        </div>
        <p>&copy; 2024 Home Care Services. All rights reserved.</p>
    </div>
</footer>

</body>
</html>
