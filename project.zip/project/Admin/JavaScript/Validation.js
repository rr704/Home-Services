function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }
  
  function validateLoginForm() {
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
  
    if (!validateEmail(email)) {
      alert('Please enter a valid email address.');
      return false;
    }
  
    if (!validatePassword(password)) {
      alert('Password must be at least 8 characters long.');
      return false;
    }
  
    return true;
  }
  
 
