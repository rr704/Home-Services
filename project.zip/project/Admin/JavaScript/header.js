function myFunction(x) {
    x.classList.toggle("change");
    var menu = document.querySelector('.header-menu');
    if (menu.style.display === "block") {
        menu.style.display = "none";
    } else {
        menu.style.display = "block";
    }
}

