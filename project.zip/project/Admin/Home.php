
    <?php include 'Header.php'; ?>
    
    <!--------------------------- section1 --------------------------->
    <div class="section1">
        <div class="left-section1">
            <div class="left-sec1">
                <h1 class="heading">Wel-Come To<br> Home Care Services</h1>
                <p class="description">Home Care services encompass a wide range of maintenance and improvement tasks designed to keep your home in optimal condition. From minor fixes like leaky faucets and electrical outlets to larger projects such as kitchen remodeling or bathroom renovations, these services address the upkeep and enhancement of your property. By hiring professionals, homeowners can save time, avoid potential hazards, and ensure that repairs are completed efficiently and to high standards.</p>
            </div>
        </div>
        <div class="right-section1">
            <img src="images/homesvg/homecare.jpg" alt="image">
        </div>
    </div>

    <!--------------------------- section2 --------------------------->
    <div class="section2">
        <div class="left-section2">
            <img src="images/homesvg/aboutus.jpg" alt="image">
        </div>
        <div class="right-section2">
            <div class="right-sec2">
                <h1 class="heading">About Us</h1>
                <p class="description">At Home Care, we are your trusted partners in home maintenance and repair. With a team of skilled and experienced technicians, we offer a comprehensive range of services to keep your home in top condition. From plumbing and electrical work to carpentry, painting, and appliance repair, we handle it all. Our commitment to quality workmanship, coupled with exceptional customer service, ensures your satisfaction. Let us take care of your home repair needs so you can enjoy the spaces you love.</p>
            </div>
        </div>
    </div>

    <!--------------------------- section3 --------------------------->
    <div class="section3">
        <div class="left-section3">
            <div class="left-sec3">
                <h1 class="heading">Our Specialization And <br> Company Features</h1>
                <p class="description">We provide expert home repair services to transform your house into a home. Our skilled technicians offer a wide range of services including plumbing, electrical work, carpentry, painting, and appliance repair. With a commitment to quality and customer satisfaction, we deliver efficient and reliable solutions for all your home maintenance needs. From minor repairs to major renovations, we're your trusted partner in home improvement.</p>
            </div>
        </div>
        <div class="right-section3">
            <img src="images/homesvg/features.jpg" alt="image">
        </div>
    </div>

    <!--------------------------- section4 --------------------------->
    <div class="section4">
        <div class="left-section4">
            <img src="images/homesvg/teamwork.jpg" alt="image">
        </div>
        <div class="right-section4">
            <div class="right-sec4">
                <h1 class="heading">Our Expert Workers</h1>
                <p class="description">Our team of seasoned home repair technicians brings a wealth of experience to every project. With a deep understanding of plumbing, electrical systems, carpentry, painting, and appliance repair, we deliver top-notch solutions for your home maintenance needs. Our commitment to staying updated with industry advancements ensures efficient and effective service. Trust our skilled professionals to handle your home repair tasks with precision and care.</p>  
            </div>
        </div>
    </div>
    
    <?php include 'Footer.php'; ?>
