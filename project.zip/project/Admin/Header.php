<?php
// Ensure session_start is called before any output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user or admin is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // If not logged in, redirect to the appropriate login page
    header('Location: admin_login.php'); // You can change this to a user login if needed
    exit();
}

// Check if it's an admin user
$is_admin = isset($_SESSION['admin_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Care Services</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="CSS/home.css">
    <script src="JavaScript/header.js"></script>
    <script src="jquery-3.7.1.min.js"></script>
</head>
<body>
    <header>
        <div class="header-container">
            <div class="logo">
                <img src="images/homeimages/1.Logo.png" alt="Home Care Service">
            </div>
            <div class="header-menu">
                <ul>
                    <li><a href="Home.php">HOME</a></li>
                    <li><a href="userrequests.php">USERS REQUESTS</a></li>
                    <li><a href="profile.php">PROFILE</a></li>
                </ul>
            </div>
            <div class='options'>
                <div class="container" onclick="myFunction(this)">
                    <div class="bar1"></div>
                    <div class="bar2"></div>
                    <div class="bar3"></div>
                </div>  
            </div>
        </div>
    </header>
    <section class="slogan">
            <h1>"Repair, Your Way!"</h1>
    </section>
</body>
</html>
