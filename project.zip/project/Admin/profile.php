<?php
session_start();

// Check if the user is logged in, redirect to login page if not
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin_login.php');
    exit;
}

// Handle the logout action
if (isset($_POST['logout'])) {
    session_destroy(); // Destroy the session to log the user out
    header('Location: Home.php');
    exit;
}

// Admin hardcoded data
$email = 'admin@gmail.com';
$password = '1234'; 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Profile - Home Care Services</title>
    <link rel="stylesheet" href="CSS/profile.css">
</head>
<body>
    <?php include 'Header.php'; ?>

    <section class="profile">
        <div class="profile-container">
            <div class="profile-header">
                <h2>Admin Profile</h2>
            </div>
            <div class="profile-details">
                <div class="profile-info">
                    <p>Email: <?php echo htmlspecialchars($email); ?></p>
                    <p>Password: <?php echo htmlspecialchars($password); ?></p>
                    <form method="POST">
                        <button type="submit" name="logout" class="logout-btn">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php include 'Footer.php'; ?>
</body>
</html>
